This is not the official release of Poppler, its just a package of pre-built binaries for the Poppler library which includes
Poppler-Cpp library and Poppler-Qt5 library.

* Built using MinGW32 4.8.1 *

This package was released by MJaoune: https://sourceforge.net/p/poppler-win32